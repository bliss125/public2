import xmlformatter
import sys
import os

file = sys.argv[1]

formatter = xmlformatter.Formatter(indent="2", indent_char=" ", encoding_output="ISO-8859-1", preserve=["literal"])
text = formatter.format_file(file)
text = text.strip()
#print(text)


f2 = open(file, 'wb')
f2.write(text)
f2.close()