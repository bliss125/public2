import xml.etree.ElementTree as ET
import sys
import os
import re

APP_XML = sys.argv[1]
newweb_uri = sys.argv[2]
newejb = sys.argv[3]
#newcontext_root = sys.argv[4]

tree = ET.parse(APP_XML)
root = tree.getroot()
ns = {"xmlns" : root.tag[1:root.tag.index('}')]}
    

#context_root = root.find("./xmlns:module/xmlns:web/xmlns:context-root", ns).text
#print('updating context-root from: ' + context_root + ' to ' + newcontext_root + ' in file: ' + APP_XML)
#os.system('python %py3_dir%\\search_replace_with_args.py ' + APP_XML + ' ' + context_root + ' ' + newcontext_root)

web_uri = root.find("./xmlns:module/xmlns:web/xmlns:web-uri", ns)
#print(web_uri)
if type(None)!=type(web_uri):
    web_uri = web_uri.text
    print('updating web-uri from: ' + web_uri + ' to ' + newweb_uri + ' in file: ' + APP_XML)
    print('------------------------------------------------------------------------------------------------------')
    os.system('python %py3_dir%\\search_replace_with_args.py ' + APP_XML + ' ' + web_uri + ' ' + newweb_uri)

ejb = root.find("./xmlns:module/xmlns:ejb", ns)
if type(None)!=type(ejb):
    ejb = ejb.text
    print('updating ejb from: ' + ejb + ' to ' + newejb + ' in file: ' + APP_XML)
    print('------------------------------------------------------------------------------------------------------')
    os.system('python %py3_dir%\\search_replace_with_args.py ' + APP_XML + ' ' + ejb + ' ' + newejb)
