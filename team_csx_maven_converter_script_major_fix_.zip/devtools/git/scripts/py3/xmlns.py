import xml.etree.ElementTree as ET
import sys
import os
import re

def get_namespace(element):
  m = re.match('\{.*\}', element.tag)
  return m.group(0) if m else ''

if len(sys.argv) == 1:
  print('error: usage test.py xml_file_path')
else:
  if os.path.exists(sys.argv[1]) == False:
    print('error: xml_file_path -- ', sys.argv[1], ' doesn not exist. Please provide valid xml file path.')
  else:
    APP_XML = sys.argv[1]
    tree = ET.parse(APP_XML)
    root = tree.getroot()
    namespace_str = get_namespace(root)
    namespace_str = namespace_str[1:len(namespace_str)-1]
    ns = {"xmlns" : namespace_str}
    
    print('------------------------------------------------------------------------------------------------------')
    print('ns: ', ns)
    print('ns: ', root.tag[1:root.tag.index('}')]
    print('------------------------------------------------------------------------------------------------------')