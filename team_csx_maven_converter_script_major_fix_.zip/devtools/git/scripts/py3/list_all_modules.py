import xml.etree.ElementTree as ET
import sys
import os
import re

if len(sys.argv) == 1:
  print('error: usage test.py xml_file_path')
else:
  if os.path.exists(sys.argv[1]) == False:
    print('error: xml_file_path -- ', sys.argv[1], ' doesn not exist. Please provide valid xml file path.')
  else:
    APP_XML = sys.argv[1]
    tree = ET.parse(APP_XML)
    root = tree.getroot()
    ns = {"xmlns" : root.tag[1:root.tag.index('}')]}

    web_modules = root.findall(".//xmlns:web-uri", ns)
    print('no.of web mnodules: ', len(web_modules))
    
    web_modules_str = ""
    for webmodule in web_modules:
      #print(webmodule.text)
      web_modules_str += webmodule.text + ';'
    
    ejb_modules_str = ""
    ejb_modules = root.findall(".//xmlns:ejb", ns)
    print('no.of ejb mnodules: ', len(ejb_modules))
    
    for ejbmodule in ejb_modules:
      #print(ejbmodule.text)
      ejb_modules_str += ejbmodule.text + ";"
    
    context_roots = root.findall(".//xmlns:context-root", ns)
    print('no.of context roots: ', len(context_roots))
    
    context_roots_str = ""
    for context_root in context_roots:
      #print(context_root.text)
      context_roots_str += context_root.text + ';'

    print('------------------------------------------------------------------------------------------------------')
    system_variable_name='context_roots'
    print('echo set "' + system_variable_name + '=' + context_roots_str + '" >> %tmp_dir%\\setmodules.bat')
    os.system('echo set "' + system_variable_name + '=' + context_roots_str + '" >> %tmp_dir%\\setmodules.bat')
    print('------------------------------------------------------------------------------------------------------')
    system_variable_name='web_modules'
    print('echo set "' + system_variable_name + '=' + web_modules_str + '" >> %tmp_dir%\\setmodules.bat')
    os.system('echo set "' + system_variable_name + '=' + web_modules_str + '" >> %tmp_dir%\\setmodules.bat')
    print('------------------------------------------------------------------------------------------------------')
    system_variable_name='ejb_modules'
    print('echo set "' + system_variable_name + '=' + ejb_modules_str + '" >> %tmp_dir%\\setmodules.bat')
    os.system('echo set "' + system_variable_name + '=' + ejb_modules_str + '" >> %tmp_dir%\\setmodules.bat')
    print('------------------------------------------------------------------------------------------------------')