import xml.etree.ElementTree as ET
import sys
import os
import re

APP_XML = sys.argv[1]
newcontext_root = sys.argv[2]

#rem %py3_dir%\ibm-web-ext_xml_parser.py ibm-web-ext.xml pa_palt
#rem for /F "tokens=*" %%i in ("dir /s/b ibm-web-ext.xml") do @IF EXIST %%i" call python %py3_dir%\ibm-web-ext_xml_parser.py %%i %1

tree = ET.parse(APP_XML)
root = tree.getroot()
ns = {"xmlns" : root.tag[1:root.tag.index('}')]}
    
context_root = root.find(".//xmlns:context-root", ns).attrib['uri']
print(context_root)
print("updating context-root from: ", context_root, " to " + newcontext_root + " in file: " + APP_XML)
os.system('python %py3_dir%\\search_replace_with_args.py ' + APP_XML + ' ' + context_root + ' ' + newcontext_root)