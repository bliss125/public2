import os
from pathlib import Path
import sys
import string

filePath=sys.argv[1]
parent_count=int(sys.argv[2])
#print(os.path.dirname(os.path.abspath(filePath)))
#print(Path(filePath).parent)
#print(Path(filePath).parent.parent)
#print(Path(filePath).parents[1])
# climb to filePath's parent's parent:
#print(os.path.abspath(filePath + "/../../"))
parent_path=Path(filePath).parents[parent_count]
print('parent_path: ', parent_path)