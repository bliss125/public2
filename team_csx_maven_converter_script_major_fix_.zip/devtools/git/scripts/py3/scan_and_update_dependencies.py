import string
import sys
from pathlib import Path
import os

if len(sys.argv) < 3:
    print('error: usage scan_and_update_dependencies.py pom_xml_path dependencies_xml_path')
else:
    if os.path.exists(sys.argv[1]) == False:
        print('error: pom_xml_path -- ', sys.argv[1], ' doesn not exist. Please provide valid pom.xml file path.')
    if os.path.exists(sys.argv[2]) == False:
        print('error: dependencies_xml_path -- ', sys.argv[2], ' doesn not exist. Please provide dependencies.xml file path.')
    else:
        POM_XML = sys.argv[1]
        DEPENDENCIES_XML = sys.argv[2]
        os.system('%bat_dir%\\dep_xml_merge_to_pom.bat ' + POM_XML + ' ' + DEPENDENCIES_XML + '')