import xml.etree.ElementTree as ET
import sys
import os

APP_XML = sys.argv[1]
new_uri = sys.argv[2]

tree = ET.parse(APP_XML)
root = tree.getroot()
#print(root)

uri = root.find("./deployedObject/modules").attrib['uri']
#print(uri)
print('------------------------------------------------------------------------------------------------------')
print('updating uri from: ' + uri + ' to ' + new_uri + ' in file: ' + APP_XML)
print('------------------------------------------------------------------------------------------------------')
os.system('python %py3_dir%\\search_replace_with_args.py ' + APP_XML + ' ' + uri + ' ' + new_uri)
print('------------------------------------------------------------------------------------------------------')