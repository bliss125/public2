import xml.etree.ElementTree as ET
import sys
import os
import string
import re

POM_XML = sys.argv[1]
new_dep_file_path = sys.argv[2]

new_dep_file = open(new_dep_file_path)
new_dep_file_str = new_dep_file.read()
new_dep_file_str = '<xml>' + new_dep_file_str + '</xml>'
new_dep_file.close()
#print(new_dep_file_str)

new_dep_root = ET.fromstring(new_dep_file_str)
new_dependencies = list(new_dep_root.iter('dependency'))
#print(len(new_dependencies))

#f2 = open(new_dep_file, 'w')
#f2.write(s)
#f2.close()

tree = ET.parse(POM_XML)
root = tree.getroot()
ns = {"xmlns" : root.tag[1:root.tag.index('}')]}

existing_dependencies = root.find("./xmlns:dependencies", ns)
#if len(existing_dependencies) == 0

for index, deps in enumerate(new_dependencies):
    existing_dependencies.append(deps)

ET.register_namespace('', ns['xmlns'])
tree.write(POM_XML)