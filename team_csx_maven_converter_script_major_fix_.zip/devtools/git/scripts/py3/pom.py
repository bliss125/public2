import xml.etree.ElementTree as ET
import sys
import os
import string

POM_XML = sys.argv[1]
OUT_XML = sys.argv[2]

'''new_dep_file_path = sys.argv[2]

new_dep_file = open(new_dep_file_path)
new_dep_file_str = new_dep_file.read()
new_dep_file_str = '<xml>' + new_dep_file_str + '</xml>'
new_dep_file.close()
#print(new_dep_file_str)

new_dep_root = ET.fromstring(new_dep_file_str)
new_dependencies = list(new_dep_root.iter('dependency'))'''
#print(len(new_dependencies))

#f2 = open(new_dep_file, 'w')
#f2.write(s)
#f2.close()

ns = {'xmlns': 'http://maven.apache.org/POM/4.0.0'}
ET.register_namespace('', ns['xmlns'])
tree = ET.parse(POM_XML)
root = tree.getroot()

existing_dependencies = root.find("./xmlns:dependencies", ns)
print('before processing duplicates - dependency size: ', len(existing_dependencies))

dep_list = set()
rem_list = set()
if len(existing_dependencies) > 0:
    for index, dep in enumerate(existing_dependencies):
        #existing_dependencies.append(dep)
        dep_str=ET.tostring(dep).decode()
        if not dep_str in dep_list:
            dep_list.add(dep_str)
            #print(dep_str)
        else:
            rem_list.add(dep)

if len(rem_list) > 0:
    for index, dup in enumerate(rem_list):
        existing_dependencies.remove(dup)

print('duplicates - dependency size: ', len(rem_list))
print('after processing duplicates - dependency size: ', len(existing_dependencies))
tree.write(OUT_XML)