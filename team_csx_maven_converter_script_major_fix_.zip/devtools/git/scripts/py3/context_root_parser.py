import xml.etree.ElementTree as ET
import sys
import os

if len(sys.argv) == 1:
    print('error: usage test.py xml_file_path')
else:
    if os.path.exists(sys.argv[1]) == False:
        print('error: xml_file_path -- ', sys.argv[1], ' doesn not exist. Please provide valid xml file path.')
    else:
        APP_XML = sys.argv[1]
        ns1 = {"xmlns": "http://java.sun.com/xml/ns/javaee"}
        ns2 = {"xmlns": "http://websphere.ibm.com/xml/ns/javaee"}
        ns3 = {"xmlns": "http://java.sun.com/xml/ns/j2ee"}
        ns = ns1

        tree = ET.parse(APP_XML)
        root = tree.getroot()
            
        context_root_obj = root.find(".//xmlns:context-root", ns)
        if type(context_root_obj) == type(None):
            ns = ns2
        
        context_root_obj = root.find(".//xmlns:context-root", ns)
        if type(context_root_obj) == type(None):
            ns = ns3

        context_root = root.find(".//xmlns:context-root", ns).text
        print('------------------------------------------------------------------------------------------------------')
        system_variable_name='context_root'
        print('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
        os.system('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
        print('------------------------------------------------------------------------------------------------------')