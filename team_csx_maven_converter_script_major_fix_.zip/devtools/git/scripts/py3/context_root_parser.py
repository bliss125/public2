import xml.etree.ElementTree as ET
import sys
import os
import re

if len(sys.argv) == 1:
  print('error: usage test.py xml_file_path')
else:
  if os.path.exists(sys.argv[1]) == False:
    print('error: xml_file_path -- ', sys.argv[1], ' doesn not exist. Please provide valid xml file path.')
  else:
    APP_XML = sys.argv[1]
    tree = ET.parse(APP_XML)
    root = tree.getroot()
    ns = {"xmlns" : root.tag[1:root.tag.index('}')]}
    
    context_root = root.find(".//xmlns:context-root", ns).text
    print('context_root: ', context_root)
    print('------------------------------------------------------------------------------------------------------')
    system_variable_name='context_root'
    print('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
    os.system('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
    print('------------------------------------------------------------------------------------------------------')