import string
import sys

file = sys.argv[1]

f1 = open(file) 
s = f1.read()

foo='" xsi:schemaLocation="'
if foo in s:
  bar='"\n  xsi:schemaLocation="'
  s = s.replace(foo, bar)

foo='<?xml version="1.0" encoding="UTF-8"?><'
if foo in s:
  bar='<?xml version="1.0" encoding="UTF-8"?>\n<'
  s = s.replace(foo, bar)

foo='" xmlns:variables="'
if foo in s:
  bar='"\n  xmlns:variables="'
  s = s.replace(foo, bar)

#foo='" xmi:id="'
#if foo in s:
  #bar='"\n  xmi:id="'
  #s = s.replace(foo, bar)

foo='" xmlns:security="'
if foo in s:
  bar='"\n  xmlns:security="'
  s = s.replace(foo, bar)

foo='" xmlns="'
if foo in s:
  bar='"\n  xmlns="'
  s = s.replace(foo, bar)

foo='" xmlns:appdeployment="'
if foo in s:
  bar='"\n  xmlns:appdeployment="'
  s = s.replace(foo, bar)

f1.close()

f2 = open(file, 'w')
f2.write(s)
f2.close()