import os
from pathlib import Path
import sys
import string

if len(sys.argv) < 3:
    print('error: usage set_cmd_variable.py env_var_name env_var_val')
else:
    env_var_name = sys.argv[1]
    env_var_val = sys.argv[2]
    print('------------------------------------------------------------------------------------------------------')
    print('echo set "' + env_var_name + '=' + env_var_val.lower() + '" >> %tmp_dir%\\setmodules.bat')
    os.system('echo set "' + env_var_name + '=' + env_var_val.lower() + '" >> %tmp_dir%\\setmodules.bat')
    print('------------------------------------------------------------------------------------------------------')