import xml.etree.ElementTree as ET
import sys
import os

APP_XML = sys.argv[1]
GIT_PROJ_ID = sys.argv[2]
GIT_REPO_ID = sys.argv[3]

#rem %py3_dir%\context_root_parser.py application.xml
#rem for /F "tokens=*" %%i in ("dir /s/b application.xml") do @IF EXIST %%i" call python %py3_dir%\context_root_parser.py %%i

ns1 = {"xmlns": "http://java.sun.com/xml/ns/javaee"}
ns2 = {"xmlns": "http://websphere.ibm.com/xml/ns/javaee"}
ns = ns1

tree = ET.parse(APP_XML)
root = tree.getroot()
#print(root)
    
context_root_obj = root.find(".//xmlns:context-root", ns)
if type(context_root_obj) == type(None):
    ns = ns2

context_root = root.find(".//xmlns:context-root", ns).text
print('------------------------------------------------------------------------------------------------------')
system_variable_name='context_root'
print('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
os.system('echo set "' + system_variable_name + '=' + context_root + '" >> %tmp_dir%\\setmodules.bat')
print('------------------------------------------------------------------------------------------------------')
#app_group=context_root.split('_')[0]
app_group=GIT_PROJ_ID.lower()
system_variable_name='app_group'
print('echo set "' + system_variable_name + '=' + app_group + '" >> %tmp_dir%\\setmodules.bat')
os.system('echo set "' + system_variable_name + '=' + app_group + '" >> %tmp_dir%\\setmodules.bat')
print('------------------------------------------------------------------------------------------------------')
#app_name=context_root.split('_')[1]
app_name=GIT_REPO_ID.lower()
system_variable_name='app_name'
print('echo set "' + system_variable_name + '=' + app_name + '" >> %tmp_dir%\\setmodules.bat')
os.system('echo set "' + system_variable_name + '=' + app_name + '" >> %tmp_dir%\\setmodules.bat')
print('------------------------------------------------------------------------------------------------------')
system_variable_name='lower_git_proj_id'
git_proj_id_to_lowercase=GIT_PROJ_ID.lower()
print('echo set "' + system_variable_name + '=' + git_proj_id_to_lowercase + '" >> %tmp_dir%\\setmodules.bat')
os.system('echo set "' + system_variable_name + '=' + git_proj_id_to_lowercase + '" >> %tmp_dir%\\setmodules.bat')
print('------------------------------------------------------------------------------------------------------')
system_variable_name='lower_git_repo_id'
git_repo_id_to_lowercase=GIT_REPO_ID.lower()
print('echo set "' + system_variable_name + '=' + git_repo_id_to_lowercase + '" >> %tmp_dir%\\setmodules.bat')
os.system('echo set "' + system_variable_name + '=' + git_repo_id_to_lowercase + '" >> %tmp_dir%\\setmodules.bat')
print('------------------------------------------------------------------------------------------------------')