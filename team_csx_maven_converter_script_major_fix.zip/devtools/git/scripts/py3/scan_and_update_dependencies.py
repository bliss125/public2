import string
import sys
from pathlib import Path
import os
 
dep_xml = sys.argv[1]
mvn_project_path = sys.argv[2]
mvn_ear_path = sys.argv[3]
mvn_ejb_path = sys.argv[4]
mvn_war_path = sys.argv[5]

git_ear_path = sys.argv[6]
git_ejb_path = sys.argv[7]
git_war_path = sys.argv[8]

if dep_xml.find(git_ejb_path)!=-1:
    os.system('%bat_dir%\\dep_xml_merge_to_pom.bat ' + mvn_ejb_path + '\\pom.xml ' + dep_xml + '')
elif dep_xml.find(git_war_path)!=-1:
    os.system('%bat_dir%\\dep_xml_merge_to_pom.bat ' + mvn_war_path + '\\pom.xml ' + dep_xml + '')
elif dep_xml.find(git_ear_path)!=-1:
    #os.system('%bat_dir%\\dep_xml_merge_to_pom.bat ' + mvn_ear_path + '\\pom.xml ' + dep_xml + '')
	#common jars for all modules should be in main pom.xml file
	os.system('%bat_dir%\\dep_xml_merge_to_pom.bat ' + mvn_project_path + '\\pom.xml ' + dep_xml + '')