import string
import sys
#import re
 
file = sys.argv[1]
foo = sys.argv[2]
bar = sys.argv[3]

f1 = open(file) 
s = f1.read()
s = s.replace(foo, bar)

f1.close()

f2 = open(file, 'w')
f2.write(s)
f2.close()